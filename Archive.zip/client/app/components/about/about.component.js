'use strict';

import template from './about.html';
import controller from './about.controller';

export default {
  restrict: 'E',
  bindings: {},
  template,
  controller,
  controllerAs: 'vm'
};
