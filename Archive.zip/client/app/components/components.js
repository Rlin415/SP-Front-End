"use strict";

import angular from 'angular';
import About from './about/about';

export default angular.module('app.components', [
  About.name
]);
