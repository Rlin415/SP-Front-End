"use strict";

import template from './app.html';

export default {
  template,
  restrict: 'E'
};
