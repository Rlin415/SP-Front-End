"use strict";

const User = require('./user.model');

module.exports = {
  User: User
};
